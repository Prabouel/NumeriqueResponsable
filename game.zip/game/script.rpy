# MISSION NUMÉRIQUE - Jeu pédagogique Ren'Py pour collégiens

init -2 python:
    config.screen_width = 1280
    config.screen_height = 720

define e = Character("Élève", color="#9fe8ff")
define n = Character(None)
default score = 0
default erreurs = 0
default niveau = 1
default use_sfx = True
default use_music = True

init python:
    import random
    def shuffled_menu(choices):
        result = list(choices)
        random.shuffle(result)
        return result
    def play_optional_sound(filename):
        if use_sfx and renpy.loadable(filename):
            renpy.sound.play(filename)
    def start_optional_music(filename):
        if use_music and renpy.loadable(filename):
            renpy.music.play(filename, loop=True, fadein=1.5)
    def stop_optional_music():
        renpy.music.stop(fadeout=1.0)

image bg mission = im.Scale("images/background.png", 1280, 720)
image logo mission = im.Scale("images/logo.png", 900, 323)

style say_dialogue:
    size 25
style say_label:
    size 26

screen choice(items):
    style_prefix "choice"
    vbox:
        xalign 0.5
        yalign 0.62
        xsize 1020
        spacing 10
        for i in items:
            textbutton i.caption:
                action i.action
                xsize 1020
                xpadding 24
                ypadding 12
                text_size 22
                text_text_align 0.5
                text_xalign 0.5

screen hud():
    frame:
        xalign 0.02
        yalign 0.02
        padding (12, 8)
        background "#07162ccc"
        text "Score : [score]/4   Erreurs : [erreurs]   Niveau : [niveau]/4" size 19 color "#ffffff"

screen card(txt):
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1040
        xmaximum 1040
        ymaximum 610
        padding (28, 22)
        background "#07162cee"
        vbox:
            xfill True
            spacing 18
            text txt:
                size 24
                xmaximum 970
                xalign 0.5
                text_align 0.5
                color "#ffffff"
            textbutton "CONTINUER":
                action Return()
                xalign 0.5
                text_size 21

screen audio_settings():
    frame:
        xalign 0.98
        yalign 0.02
        padding (10, 6)
        background "#07162ccc"
        hbox:
            spacing 7
            text "Effets" size 16
            textbutton ("ON" if use_sfx else "OFF"):
                action ToggleVariable("use_sfx")
                text_size 16
            text "Musique" size 16
            textbutton ("ON" if use_music else "OFF"):
                action [ToggleVariable("use_music"), Function(renpy.music.set_pause, use_music)]
                text_size 16

label start:
    $ score = 0
    $ erreurs = 0
    $ niveau = 1
    scene bg mission
    show screen hud
    show screen audio_settings
    $ start_optional_music("audio/theme.ogg")
    show logo mission at truecenter
    with dissolve
    $ renpy.pause(2.0)
    hide logo mission
    with dissolve
    call screen card("Bienvenue dans MISSION NUMÉRIQUE !\n\nDécouvre des gestes simples pour profiter du numérique tout en limitant son impact environnemental.\n\nQuatre situations t'attendent.")
    jump question1

label question1:
    $ niveau = 1
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 1 - Le téléphone encore utilisable"
    n "Ton téléphone fonctionne encore, mais un modèle plus récent vient de sortir."
    e "Quel choix limite généralement le mieux l'impact environnemental ?"
    $ opts = shuffled_menu([
        ("Le remplacer immédiatement pour avoir le dernier modèle", "q1_r1"),
        ("Le conserver, le protéger et le réparer lorsqu'une réparation raisonnable est possible", "q1_r2"),
        ("Acheter le nouveau et laisser l'ancien dans un tiroir", "q1_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q1_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Fabriquer un nouvel appareil mobilise des matières premières, de l'énergie et du transport."
    jump q1_explication

label q1_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : prolonger la durée de vie évite ou retarde la fabrication d'un nouvel appareil."
    jump q1_explication

label q1_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Un appareil inutilisé ne remplace pas un recyclage, un don ou un réemploi."
    jump q1_explication

label q1_explication:
    call screen card("À RETENIR\n\nUne grande partie de l'impact d'un appareil vient de sa fabrication. Le garder plus longtemps, l'entretenir et le réparer sont des gestes importants.")
    jump question2

label question2:
    $ niveau = 2
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 2 - La vidéo répétée"
    n "Tu regardes plusieurs fois la même longue vidéo sur un petit écran, en très haute définition et avec une connexion mobile."
    e "Comment réduire les transferts de données sans renoncer au contenu ?"
    $ opts = shuffled_menu([
        ("Choisir une définition adaptée et utiliser le téléchargement ou le Wi-Fi si cela convient", "q2_r1"),
        ("Augmenter encore la définition, même si l'écran ne montre pas la différence", "q2_r2"),
        ("Lancer la vidéo en arrière-plan sans la regarder", "q2_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q2_r1:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : une qualité adaptée à l'écran et moins de transferts répétés peuvent réduire l'usage de données."
    jump q2_explication

label q2_r2:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Une définition excessive transfère davantage de données sans bénéfice visible sur un petit écran."
    jump q2_explication

label q2_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Le transfert continue même si le contenu n'est pas réellement utilisé."
    jump q2_explication

label q2_explication:
    call screen card("À RETENIR\n\nAdapte la qualité vidéo à l'écran et à ton besoin. Évite les lectures inutiles et télécharge un contenu que tu dois réellement consulter plusieurs fois.")
    jump question3

label question3:
    $ niveau = 3
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 3 - Le stockage encombré"
    n "Ton espace en ligne contient plusieurs copies de longues vidéos et de gros fichiers que tu n'utilises plus."
    e "Quel geste est pertinent ?"
    $ opts = shuffled_menu([
        ("Tout conserver en plusieurs exemplaires sans vérifier", "q3_r1"),
        ("Trier les fichiers lourds, supprimer les doublons inutiles et garder ce qui a une utilité", "q3_r2"),
        ("Supprimer au hasard pour aller plus vite", "q3_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q3_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Les doublons inutiles occupent du stockage et compliquent aussi l'organisation."
    jump q3_explication

label q3_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Bonne réponse : un tri raisonné évite le stockage superflu sans supprimer les documents importants."
    jump q3_explication

label q3_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Un tri responsable doit préserver les documents utiles et importants."
    jump q3_explication

label q3_explication:
    call screen card("À RETENIR\n\nCommence par les fichiers volumineux et les doublons. Organise ce qui doit être conservé et évite les sauvegardes multiples sans utilité.")
    jump question4

label question4:
    $ niveau = 4
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 4 - L'appareil en fin de vie"
    n "Une tablette ne fonctionne plus et ne peut pas être réparée à un coût raisonnable."
    e "Que faut-il en faire ?"
    $ opts = shuffled_menu([
        ("La jeter dans la poubelle ordinaire", "q4_r1"),
        ("La confier à une filière de collecte, un magasin ou une déchèterie acceptant les appareils électroniques", "q4_r2"),
        ("La laisser dehors avec les déchets encombrants", "q4_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q4_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Les appareils électroniques nécessitent une collecte spécifique et contiennent des matériaux valorisables."
    jump q4_explication

label q4_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : elle pourra être dépolluée et ses matériaux pourront être récupérés."
    jump q4_explication

label q4_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Cela ne garantit ni le traitement adapté ni la récupération des matériaux."
    jump q4_explication

label q4_explication:
    call screen card("À RETENIR\n\nUn équipement électronique ne va pas dans la poubelle ordinaire. Efface les données si possible, puis utilise une filière officielle de collecte ou de recyclage.")
    jump bilan_final

label bilan_final:
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/victory.ogg")
    if score == 4:
        $ msg = "EXPERT : tu as acquis les quatre bons réflexes !"
    elif score >= 2:
        $ msg = "BON NIVEAU : encore quelques réflexes à consolider."
    else:
        $ msg = "EN APPRENTISSAGE : le débrief va t'aider à progresser."
    call screen card("BILAN DE LA MISSION\n\nScore : [score] / 4     Erreurs : [erreurs]\n\n[msg]\n\nLES 4 RÉFLEXES\n1. Appareil : le garder et le réparer plus longtemps.\\n2. Vidéo : adapter la qualité et limiter les transferts inutiles.\\n3. Stockage : trier surtout les fichiers lourds et dupliqués.\\n4. Fin de vie : donner, reconditionner ou recycler correctement.")
    menu:
        "Rejouer":
            jump start
        "Quitter":
            $ stop_optional_music()
            $ renpy.quit()
